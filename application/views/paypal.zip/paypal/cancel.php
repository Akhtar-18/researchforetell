<div class="status">
    <h1 class="error">Your transaction was canceled!</h1>
</div>